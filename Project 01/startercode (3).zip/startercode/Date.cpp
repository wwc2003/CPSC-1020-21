#include "Date.h"
#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>

using namespace std;

Date::Date(){
}

Date::Date( int d , int m , int y ){
}

bool Date::setDay( int d ){
  return false;
}

bool Date::setMonth( int m ){
  return false;
}

bool Date::setYear( int y ){
  return false;
}

int Date::getDay() const{
  return -1;
}

int Date::getMonth() const{
  return -1;
}

int Date::getYear() const{
  return -1;
}

string Date::showDate() const{
  return "";
}
