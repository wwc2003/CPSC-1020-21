#include "calcDays.h"
#include "Date.h"
#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

int calcDays( const Date &a , const Date &b ){
  return -1;
}
