#include "Date.h"
#include "calcDays.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

int main( int argc , char* argv[] ){
  string a = "YES";
  string b = "NO";

  cout << (a == b) << endl;
  
  return 0;
}
