#ifndef CALCDAYS_H
#define CALCDAYS_H

#include "Date.h"

using namespace std;

int calcDays( const Date &dateA , const Date &dateB );

#endif

